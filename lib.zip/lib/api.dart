class Baseurl {
  static String tambah = "http://192.168.137.107/school/controller/insert.php";
  static String data = "http://192.168.137.107/school/controller/list.php";
  static String lihat = "http://192.168.137.107/school/controller/details.php";
  static String edit = "http://192.168.137.107/school/controller/update.php";
  static String hapus = "http://192.168.137.107/school/controller/hapus.php";
}